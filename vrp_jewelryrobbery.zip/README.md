# vrp_jewelryrobberry
![Imgur](https://i.imgur.com/dkIDwQn.png)

The script includes 25 areas for jewelry collection with alarm to the police when the robbery begins.

### Dependency:
- [vRP](https://github.com/DunkoUK/dunko_vrp)

### Installation:
- Enter the script folder of your resource folder
- Insert the file named `jewelryrobberry.lua` into the `vrp\cfg\item` directory and then insert the `load_item_pack("jewelryrobberry")` string above `return cfg` in the `items.lua` file in the `vrp\cfg` folder
- Start the `vrp_jewelryrobberry` resource in .cfg file

The script includes in one of the 25 areas of the robbery also one in which money is stolen from the jewelery case.

The script is not optimized to the maximum, in case someone wants to optimize it before republishing it in its own github respository or in fivem releases, it is obliged to communicate it to me and request my authorization.
At that time when you download it you can change it to your liking without any problem but you cannot store it on third-party sites or fivem or github sites.

### Support
[![Discord](https://i.imgur.com/9GFVWqX.png)](https://discord.gg/Ev9WBKy) [![Telegram](https://i.imgur.com/RcZ4ALP.png)](https://t.me/Dracke)

## Started robberry blips appearance
![Imgur](https://i.imgur.com/LwFXack.png)
## Robbery area
![Imgur](https://i.imgur.com/JQorfed.jpg)
## Start robberry area
![Imgur](https://i.imgur.com/pcIQG8R.png)
## Messages as the robbery
![Imgur](https://i.imgur.com/6HjsCJT.jpg) ![Imgur](https://i.imgur.com/VhcEuLE.jpg)


## Changelog:
- Added `jewelryrobberry.lua` file (08/02/2020)

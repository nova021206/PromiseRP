
local items = {}

--items["jewelry"] = {"Jewelry","",nil,0.2}

return items
